from project.animal import Animal


class Reptile(Animal):
    pass